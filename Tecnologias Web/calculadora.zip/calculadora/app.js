function calcularSoma() {
    let n1 = parseFloat(document.getElementById("numero1").value);
    let n2 = parseFloat(document.getElementById("numero2").value);

    let resultado = n1 + n2;
    document.getElementById('resultado').innerHTML = resultado;
    
}
function dividir(){
    let n1 = parseFloat(document.getElementById("numero1").value);
    let n2 = parseFloat(document.getElementById("numero2").value);

    if(n2 === 0){
        document.getElementById('resultado').innerHTML = "Não é possível dividir por 0";
    }
    else {
        let resultado = n1 / n2
        document.getElementById('resultado').innerHTML = resultado;
    }
}

function produto(){
    let n1 = parseFloat(document.getElementById("numero1").value);
    let n2 = parseFloat(document.getElementById("numero2").value);

    let resultado = n1 * n2
    document.getElementById('resultado').innerHTML = resultado;

}

function subtrair(){
    let n1 = parseFloat(document.getElementById("numero1").value);
    let n2 = parseFloat(document.getElementById("numero2").value);
    let resultado = n1 - n2
    document.getElementById('resultado').innerHTML = resultado;

}


function limparResultado() {
    document.getElementById('numero1').value='';
    document.getElementById('numero2').value='';
    document.getElementById('resultado').innerHTML = '';
}