let lista_par = []
let lista_impar = []
let somap = 0
let somai = 0
function adicionar(numero) {
    numero = document.getElementById("numero").value;
    if (numero % 2 === 0) {
        lista_par.push(numero);
    } else {
        lista_impar.push(numero);
    }
    console.log(lista_par)
    console.log(lista_impar)
    
}
