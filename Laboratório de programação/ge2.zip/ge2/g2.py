# PRIMEIRA QUESTAO
'''
A = 0
B = 0
C = 0
qtd = []
votacao = ['A','B','C']

votar = input("Digite os votos: ").upper().strip()
lista_votacao = votar.split(" ")




for letra in range(len(lista_votacao)):
    if lista_votacao[letra] == "A":
        A += 1
    elif lista_votacao[letra] == "B":
        B += 1
    else:
        C += 1

qtd.append(A)
qtd.append(B)
qtd.append(C)

votos = dict(zip(votacao,qtd))

for voto in votos:
    voto_final = votos[voto]
    print(f" Votos tipo {voto} é: {voto_final}")
    '''



# SEGUNDA QUESTÃO
passou = 0

with open("leituras.txt", "r", encoding="utf-8") as arquivo:
    for linha in arquivo:
        validas = []
        dados = linha.strip().split(",")
        nome = dados[0]
        temp = dados[1]
        status = dados[2].strip()
        if float(temp) >= 50 and status == "OK":
            passou += 1
            with open("alertas.txt", "w", encoding = "utf-8") as final:
                for i in range(passou):
                    final.write(f"{nome}, {temp}, {status} \n")

print(f"O arquivo alertas.txt foi gerado com {passou} registros")
            








































